import { StyleSheet, Text, View } from 'react-native';
import React from 'react';

const MainStack = () => {
  return (
    <View>
      <Text>MainStack</Text>
    </View>
  );
};

export default MainStack;

const styles = StyleSheet.create({});
